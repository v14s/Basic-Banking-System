<?php
$con=mysqli_connect('localhost','root','','bank_system');  
$id=$_GET['id'];
	$sql="delete from createuser where id='$id' ";
	
	$result=mysqli_query($con,$sql);
	if($result)
	{
		header("Location:account_tbl.php");
	}
	else
	{
		echo "Unable delete".mysqli_error($con);
	}
?>
